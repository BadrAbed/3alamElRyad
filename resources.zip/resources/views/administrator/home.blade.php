@extends("administrator.include.master")

@section("content")

@endsection