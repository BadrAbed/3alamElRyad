<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpectedResult extends Model
{
    //
}
