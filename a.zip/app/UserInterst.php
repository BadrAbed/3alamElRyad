<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserInterst extends Model
{
    //
}
