<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlayerMatch extends Model
{
    //
}
